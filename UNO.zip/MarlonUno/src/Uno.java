import java.util.ArrayList;

import view.Startmenu;

/**
 * Main method to start the program
 * 
 * @author Marlon Weiss & Marlon Loretz
 * @version 1.1
 * @date 06.06.2019
 *
 */
public class Uno {
	
	public static void main(String[] args) {
		
		Startmenu s = new Startmenu();
		
		

	}
}